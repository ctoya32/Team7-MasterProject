//the main project, with buttons and slides and stuff.

let pic1
function preload() {
  pic1 = loadImage('pic1.jpeg');
}

function setup() {
  createCanvas(900, 550);
  startScreen();
}



function startScreen(){
  background(120);
  startButtonFunction();
  textSize(32);
  textFont('Georgia')
  text('Welcome to your own \npersonalized FMS experience!', 280, 200);
}

function startButtonFunction(){
  //start button
  
  let startButton = createButton('Start Here');
  
  startButton.position(350,300);
  startButton.size(200,80);
  startButton.style('font-size','30px');
  
  //goes to title screen
  startButton.mousePressed(function(){
    startButton.remove();
    titleScreen();
  })
  

  
}
function titleScreen(){
  background(200);
  
  let typingButton = createButton('Typing Words');
  typingButton.size(160,80);
  typingButton.position(100, 350)
  typingButton.style('font-size','24px');
typingButton.mousePressed(function(){typingGame()})
  
  textSize(16);
  textFont('Georgia')
  text('Using one or more fingers \nto improve Muscle Memory', 80, 480);
   typingButton.mousePressed(function(){
    image(pic1, 0, 0);
  })
  
  let tracingButton = createButton('Tracing Shapes');
  tracingButton.size(160,80);
  tracingButton.position(375,350)
  tracingButton.style('font-size','24px');
  tracingButton.mousePressed(function(){tracingGame()})
  
  textSize(16);
  textFont('Georgia')
  text('Improves hand-eye coordination \nwithout clicking involved', 350, 480);
   
  
  
  let circleButton = createButton('Circle Clicking');
  circleButton.size(160,80);
  circleButton.position(650,350)
  circleButton.style('font-size','24px');
  circleButton.mousePressed(function(){circleGame()})
  
  textSize(16);
  textFont('Georgia')
  text('Hand-eye coordination \ntraining with clicking', 650, 480);
  
stroke(0)
  noFill()
  rect(70,460,210,50,15); //1st
  rect(340,460,250,50,15); //2nd
  rect(635,460,190,50,15); //3rd
}


function xButtonFunction(){
  
  let xButton = createButton('X');
  xButton.size(25,25)
  xButton.position(875,0);
  xButton.style('font-size','14px');
  //xButton.mousePressed()
  
}

function typingGame(){}

function tracingGame(){}

function circleGame(){}

function draw() {
  

}
  